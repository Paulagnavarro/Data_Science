#ETL Microdados do INEP = Educação Superior
#Autor: Ana
#Data: 14/08/2023

#Conectar na base do DW_INEP
import mysql.connector
import pandas as pd
#Dictionary com a config do banco para conexão
config = {
    'user':'root',
    'password': 'positivo',
    'host': 'localhost',
    'database': 'dw_inep'
}

try:
    conn = mysql.connector.connect(**config)
    cursor = conn.cursor()
    dados = pd.read_csv(
        'C:/Users/Aluno/Downloads/microdados_censo_da_educacao_superior_2020/Microdados do Censo da Educação Superior 2020/dados/MICRODADOS_CADASTRO_CURSOS_2020.CSV',
        sep=';',
        encoding='iso-8859-1'
    )
    dados = dados.fillna('')
    
    #Dados UF
    # dados_uf = pd.DataFrame(dados['NO_UF'].unique(),columns= ['uf'])
    # cursor = conn.cursor()
    
    # for i, r in dados_uf.iterrows():
    #     insert_statement = 'insert into dim_uf (tf_uf, uf) values ('\
    #                                     +str(i) +',\''\
    #                                     + str(r['uf']) +'\')'
    #     cursor.execute(insert_statement)
    #     conn.commit()

    #Municipio
    # dados_municipio = pd.DataFrame(dados['NO_MUNICIPIO'].unique(), columns=['Municipio'])
    # dados_municipio = dados_municipio.fillna('')
    # for i,r in dados_municipio.iterrows():
    #     municipio = r['Municipio']
    #     municipio = municipio.replace("'","")
    #     insert_statement = f"insert into dim_municipio(tf_municipio, municipio) values({i}, '{municipio}')"
    #     print(insert_statement)
    #     cursor.execute(insert_statement)
    #     conn.commit()

    # for i, r in dados.iterrows():
    #     matriculas = r['QT_INSCRITO_TOTAL']
    #     municipio = r['NO_MUNICIPIO']
    #     municipio = municipio.replace("'","")
    #     uf = r['NO_UF']
    #     uf = uf.replace("'","")
    #     insert_statement = f"insert into fact_matriculas(matriculas,tf_municipio,tf_uf"\
    #                         "select * from "\
    #                         "(select {matriculas} as matriculas) as matriculas,"\
    #                         "(select distinct tf_municipio from dim_municipio where municipio = '{municipio}' limit 1) as tf_municipio, "\
    #                         "(select distinct tf_uf from dim_uf where uf='{uf}' limit 1) as tf_uf;"
    #     cursor.execute(insert_statement)
    #     conn.commit()


    # modalidade ensino
    # dados_modalidade = pd.DataFrame(dados['TP_MODALIDADE_ENSINO'].unique(), columns = ['tp_modalidade_ensino'])
    # for i, r in dados_modalidade.iterrows():
    #     if r['tp_modalidade_ensino'] == 1:
    #         insert_statement = f"insert into dim_modalidade(tf_modalidade, modalidade) values({r['tp_modalidade_ensino']}, 'Presencial')"
    #     elif r['tp_modalidade_ensino'] == 2:
    #         insert_statement = f"insert into dim_modalidade (tf_modalidade, modalidade) values({r['tp_modalidade_ensino']}, 'EAD')"

    #     cursor.execute(insert_statement)
    #     conn.commit()

    # curso
    # dados_curso = pd.DataFrame(dados['NO_CURSO'].unique(), columns = ['curso'])
    # for i,r in dados_curso.iterrows():
    #     insert_statement = f"insert into dim_curso (tf_curso, curso) values({i+1}, '{r['curso']}')"
    #     cursor.execute(insert_statement)
    #     conn.commit()

    #ano
    # dados_ano = pd.DataFrame(dados['NU_ANO_CENSO'].unique(), columns = ['ano'])
    # for i,r in dados_ano.iterrows():
    #     insert_statement = f"insert into dim_ano (tf_ano, ano) values({i+1}, '{r['ano']}')"
    #     cursor.execute(insert_statement)
    #     conn.commit()

    #ies
    dados_IES = pd.read_csv('C:/Users/Aluno/Downloads/microdados_censo_da_educacao_superior_2020/Microdados do Censo da Educação Superior 2020/dados//MICRODADOS_CADASTRO_IES_2020.CSV'
                            ,sep=';'
                            , encoding ='iso-8859-1'
                            , low_memory=False)
    dados_IES = dados_IES[['CO_IES','NO_IES']]

    dados_IES_curso = pd.DataFrame(dados['CO_IES'].unique(), columns = ['co_ies'])
    for i,r in dados_IES_curso.iterrows():
        #determinar o nome da ies
        dados_IES_filtrado=dados_IES[dados_IES['CO_IES'] == r['co_ies']]
        no_ies = dados_IES_filtrado['NO_IES'].iloc[0].replace("'", "")
        insert_statement = f"insert into dim_ies (tf_ies, ies) values({i+1}, '{no_ies}')"
        cursor.execute(insert_statement)
        conn.commit()

    # fact matriculas
    for i,r in dados;
        insert_statement = 'insert into fact_matriculas(matriculas, tf_curso, tf_ies, tf_uf, tf_municipio, tf_modalidade)'
        'select*from '\
        '()'

except Exception as e:
    print(e)
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans # carregando o indutor do KMeans 
from scipy.spatial.distance import cdist # para calcular as distâncias relativas
import numpy as np
import math

fertility = pd.read_csv('C:/Users/Aluno/Documents/Clusters/fertility.txt', sep= ',')
#print(fertility.head())
fertility_atributos = fertility.drop(columns='Output')
# print(fertility_atributos.head())
for x in range(1,151):
    print(x)


distorcoes = []
K = range(1,101)
for k in K:
    fertility_kmeans_model = KMeans(n_clusters=k).fit(fertility_atributos)
    distorcoes.append(
        sum(np.min(
            cdist(fertility_atributos, fertility_kmeans_model.cluster_centers_,'euclidean'), axis =1
        )/fertility.shape[0])
    )
print(distorcoes)

fig, ax = plt.subplots()
ax.plot(K, distorcoes)
ax.set(xlabel = 'n Clusters', ylabel = 'Distorcao', title = 'Elbow (pelas distorcoes)')
fig.savefig('elbow_iris_distorcao.png')
plt.show()


x0 = K[0]
y0 = distorcoes[0]

x1 = K[len(K)-1]
y1 = distorcoes[len(distorcoes)-1]

print('Pares inicial e final do gráfico das distorcoes:')
print('Primeiro par:', x0, ',', y0)
print('Ultimo par:', x1, '', y1)

distancias = []
for i in range(len(distorcoes)):
    x = K[i]
    y = distorcoes = abs((y1-y0)*x - (x1-x0)*y + x1*y0 - y1*x0)
    denominador = math.sqrt((y1-y0)**2 + (x1-x0)**2)
    distancias.append(numerador/denomiador)

print(distancias)
print('maior distância')
print(np.max(distancias))
print('Posicao da maior distancia dentro da matriz distancias')


n_clusters_otimo =K[distancias.index(np.max(distancias))]
print('Numero ideal de clusters:', K[distancias.index(np.max(distancias))])

fertility_kmeans_model = KMeans(n_clusters=n_clusters_otimo).fit(fertility_atributos)
print('Centroides obtidos:')
print(fertility_kmeans_model.cluster_centers_)

from pickle import dump
dump(fertility_kmeans_model, open('fertility_kmeans_model_1.pkl', 'wb'))

n=98
novo_paciente = fertility_atributos.iloc[n]
print('Novo paciente original:', novo_paciente)
cluster_paciente = fertility_kmeans_model.predict(novo_paciente)
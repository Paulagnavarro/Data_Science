import pandas as pd

dados = pd.read_csv('C:/Users/Aluno/Documents/Clusters/dados_normalizar.csv', sep= ';')

dados_num = dados.drop(columns=['sexo'])
#dados_num.head()
dados_cat = dados['sexo']

# normalizar os dados categóricos( coluna sexo)
dados_cat_normalizado = pd.get_dummies(data=dados_cat, prefix_sep='_', prefix='sexo')
print(dados_cat_normalizado)

from sklearn import preprocessing
normalizador = preprocessing.MinMaxScaler()
modelo_normalizador =  normalizador.fit(dados_num) # treinar o modelo que normalizará todos os dados relativos
dados_num_normalizado = modelo_normalizador.fit_transform(dados_num)
print(dados_num_normalizado)

# recompor os dados normalizados em um objeto do tipo DataFrame
dados_finais = pd.DataFrame(data = dados_num_normalizado, columns = ['idade', 'altura', 'Peso'])
#juntar os dados numéricos normalizados com os dados categoricos normalizados
dados_final = dados_final.join(dados_cat_normalizado, how = 'left')
print(dados_final)

# salvar o normalizador para uso posterior
from pickle import dump
dump(modelo_normalizador, open('C:/Users/Aluno/Documents/Clusters/dados/modelo_normalizador_1.pkl', 'wb'))

# normalizar os dados de um novo paciente(instancia desconhecida)
#carregar o modelo normalizador

from pickle import load
modelo_normalizador = load(open('C:/Users/Aluno/Documents/Clusters/dados/modelo_normalizador_1.pkl', 'wb'))

novo_paciente = [[51,1.86,84]]
novo_paciente_normalizado = modelo_normalizador.transform(novo_paciente)
print(novo_paciente_normalizador)

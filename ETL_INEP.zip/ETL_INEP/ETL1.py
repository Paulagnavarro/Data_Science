# ETL Microdados do INEP - Educação Superior

# conectar na base do DW_INEP 
import mysql.connector
import pandas as pd
#dictionary com a config do banco para conexão
config = {
    'user': 'root',
    'password': 'positivo',
    'host': 'localhost',
    'database': 'dw_inep'
};

try:
    conn = mysql.connector.connect(**config)
    dados = pd.read_csv(
        'C:/Users/Aluno/Downloads/microdados_censo_da_educacao_superior_2020/Microdados do Censo da Educação Superior 2020/dados/MICRODADOS_CADASTRO_CURSOS_2020.CSV',
        sep=';',
        encoding='iso-8859-1'
    )
   # print(dados.head(10))

    dados_uf = pd.DataFrame(dados['NO_UF'].unique(), columns = ['uf'])
    cursor = conn.cursor()
    for i, r in dados_uf.iterrows():
        insert_statement = 'insert into dim_uf (tf_uf, uf) values ('\
                            +str(i) +',\''\
                            +str(r['uf']) + '\')'
        cursor.execute(insert_statement)
        conn.commit()
   # print(dados_uf)


except Exception as e:
    print(e)

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

#from google.colab import drive
#drive.mount('/content/drive')

df = pd.read_csv('C:/Users/Aluno/Documents/FORECASTING/airline-passengers.csv', index_col = 'Month', parse_dates = True)

print(df.head())

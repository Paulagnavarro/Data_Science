import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

#from google.colab import drive
#drive.mount('/content/drive')

df = pd.read_csv('C:/Users/Aluno/Documents/FORECASTING/airline-passengers.csv', index_col = 'Month', parse_dates = True)

# print(df.head())
# df.plot()
# plt.show()

from statsmodels.tsa.seasonal import seasonal_decompose
decompose_result = seasonal_decompose(df['Passengers'], model = 'multiplicative')
decompose_result.plot()
plt.show()

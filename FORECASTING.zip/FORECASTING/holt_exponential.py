import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

#from google.colab import drive
#drive.mount('/content/drive')

df = pd.read_csv('C:/Paula/FORECASTING/airline-passengers.csv', index_col = 'Month', parse_dates = True)

# print(df.head())
# df.plot()
# plt.show()

from statsmodels.tsa.seasonal import seasonal_decompose
decompose_result = seasonal_decompose(df['Passengers'], model = 'multiplicative')
decompose_result.plot()
plt.show()


df.index.freq = 'MS'
# Definir o valor de Alpha e o valor de m(período cronológico)
m = 12
alpha = 1/(2*m)

from statsmodels.tsa.holtwinters import SimpleExpSmoothing 
df['HWES1'] = SimpleExpSmoothing(df['Passengers']).fit(smoothing_level=alpha,optimized=False,use_brute=True).fittedvalues
df[['Passengers', 'HWES1']].plot(title='Holt winters single Exponential Smoothing');



from statsmodels.tsa.holtwinters import ExponentialSmoothing
df['HWES2_ADD'] = ExponentialSmoothing(df['Passengers'],trend='add').fit().fittedvalues
df['HWES2_MUL'] = ExponentialSmoothing(df['Passengers'],trend='mul').fit().fittedvalues
df[['Passengers','HWES2_ADD', 'HWES2_MUL']].plot(title='Holt Winters Double Exponential Smoothing: Additiv and Multiplicative Trend')


# avaliando o erro dos modelos
df['e_hws3_mull'] = abs(df['HWES2_ADD'] - df['Passengers'])
df['e_hws3_add'] = abs(df['HWES2_MUL'] - df['Passengers'])
print(df['e_hws3_mull'].mean())
print(df['e_hws3_add'].mean())



#TREINANDO UM MODELO PARA FORECASTING
df_train=df[:120]
df_test=df[120:]

fitted_model = ExponentialSmoothing(df['Passengers'],trend='mul',seasonal='mul',seasonal_periods=12).fit()
test_predictions = fitted_model.forecast(24)

df['Passengers'].plot(legend=True,label='TRAIN')
df['Passengers'].plot(legend=True,label='TEST',figsize=(6,4))
test_predictions.plot(legend=True,label='PREDICTION')
plt.title('Train, Test and Predicted Test -  Holt Winters')
plt.show()
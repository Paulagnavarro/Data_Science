#ETL Microdados do INEP = Educação Superior
#Autor: Ana
#Data: 14/08/2023

#Conectar na base do DW_INEP
import mysql.connector
import pandas as pd
#Dictionary com a config do banco para conexão
config = {
    'user':'root',
    'password': 'positivo',
    'host': 'localhost',
    'database': 'dw_inep'
}

try:
    conn = mysql.connector.connect(**config)
    cursor = conn.cursor()
    dados = pd.read_csv(
        'C:/Users/Aluno/Downloads/microdados_censo_da_educacao_superior_2020/Microdados do Censo da Educação Superior 2020/dados/MICRODADOS_CADASTRO_CURSOS_2020.CSV',
        sep=';',
        encoding='iso-8859-1'
    )
    dados = dados.fillna('')
    
    #Dados UF
    # dados_uf = pd.DataFrame(dados['NO_UF'].unique(),columns= ['uf'])
    # cursor = conn.cursor()
    
    # for i, r in dados_uf.iterrows():
    #     insert_statement = 'insert into dim_uf (tf_uf, uf) values ('\
    #                                     +str(i) +',\''\
    #                                     + str(r['uf']) +'\')'
    #     cursor.execute(insert_statement)
    #     conn.commit()

    #Municipio
    # dados_municipio = pd.DataFrame(dados['NO_MUNICIPIO'].unique(), columns=['Municipio'])
    # dados_municipio = dados_municipio.fillna('')
    # for i,r in dados_municipio.iterrows():
    #     municipio = r['Municipio']
    #     municipio = municipio.replace("'","")
    #     insert_statement = f"insert into dim_municipio(tf_municipio, municipio) values({i}, '{municipio}')"
    #     print(insert_statement)
    #     cursor.execute(insert_statement)
    #     conn.commit()

    for i, r in dados.iterrows():
        matriculas = r['QT_INSCRITO_TOTAL']
        municipio = r['NO_MUNICIPIO']
        municipio = municipio.replace("'","")
        uf = r['NO_UF']
        uf = uf.replace("'","")
        insert_statement = f"insert into fact_matriculas(matriculas,tf_municipio,tf_uf"\
                            "select * from "\
                            "(select {matriculas} as matriculas) as matriculas,"\
                            "(select distinct tf_municipio from dim_municipio where municipio = '{municipio}' limit 1) as tf_municipio, "\
                            "(select distinct tf_uf from dim_uf where uf='{uf}' limit 1) as tf_uf;"
        cursor.execute(insert_statement)
        conn.commit()

except Exception as e:
    print(e)
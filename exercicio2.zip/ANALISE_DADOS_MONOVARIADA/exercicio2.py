import seaborn as sns   
import matplotlib.pyplot as plt
import random
import numpy as np


serie = np.array([3,90,23,46,2,42,47,37,12,51,11,1,3,3,45,3,4,11,2,8,56,39,22,16,5,52])
serie_media = np.zeros(len(serie))
serie_limite_superior = np.zeros(len(serie))
serie_limite_inferior = np.zeros(len(serie))

serie_media[:] = serie.mean()
serie_limite_superior[:] = serie.mean() + serie.std()
serie_limite_inferior[:] = serie.mean() - serie.std()

sns.lineplot(serie)
sns.lineplot(serie_media)
sns.lineplot(serie_limite_superior)
sns.lineplot(serie_limite_inferior)
plt.show()

q1 = np.quantile(serie, 0.25)
q2 = np.quantile(serie, 0.5)
q3 = np.quantile(serie, 0.75)

print(q1, q2, q3)

# tempos muito rapidos

velocidade_muito_rapidos = [num for num in serie if num < q1]
velocidade_rapidos = [num for num in serie if num >= q1 and num < q2]
velocidade_lentos = [num for num in serie if num >= q2 and num < q3]
velocidade_muito_lentos = [num for num in serie if num >= q3]

#medicamentos (indices da serie de valores) de acordo com os quartis
medicamentos_muito_rapidos = [i+1 for i, num in enumerate(serie) if num < q1]
medicamentos_rapidos = [i+1 for i, num in enumerate(serie) if num >= q1 and num <q2]
medicamentos_lentos = [i+1 for i, num in enumerate(serie) if num>= q2 and num < q3]
medicamentos_muito_lentos= [i+1 for i, num in enumerate(serie) if num >= q3]

print(' Medicamentos muito rápidos: ', medicamentos_muito_rapidos)
print('Medicamentos rápidos: ', medicamentos_rapidos)
print('Medicamentos lentos', medicamentos_lentos)
print('Medicamentos muito Lentos: ', medicamentos_muito_lentos)

print('Muito rápidos: ', velocidade_muito_rapidos)
print('Rápidos: ', velocidade_rapidos)
print('Lentos', velocidade_lentos)
print('Muito Lentos: ', velocidade_muito_lentos)

import seaborn as sns   
import matplotlib.pyplot as plt
import random
import numpy as np
serie = []  #lista vazia
# for i in range(0,10):
#     print(i) 

# série aleatória de 100 valores entre 7 e 500
serie = random.sample(range(7,500), 100)
# print(serie)
# print(type(serie))
#converter a list em ndarray (vetor de numeros)
serie = np.array(serie)
# média, desvio padrão e mediana
print(serie.mean())   #média
print(np.median(serie)) # mediana
print(serie.std())  # desvio padrão

#amplitude de classes com quartis
min = serie.min()
q1 = np.quantile(serie, 0.25)
q2 = np.quantile(serie, 0.5)
q3 = np.quantile(serie, 0.75)
max = serie.max()

print(min,q1,q2,q3,max)

# Gráfico de densidade
# sns.kdeplot(serie)
# plt.show()


sns.boxplot(data = serie, palette="Set3", showfliers=True)
plt.title("Amplitudes da série de dados")
plt.show()
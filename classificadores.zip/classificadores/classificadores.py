import pandas as pd
dados = pd.read_csv('C:/Users/Aluno/Documents/classificadores/breast-cancer.csv', sep= ',')
print('# Frequencia das classes(atributo Output)')
print(dados.Class.value_counts())

from imblearn.over_sampling import SMOTE
dados_classes = dados['Class']
dados_atributos = dados.drop(columns=['Class'])

# NORMALIZAR OS DADOS
dados_atributos_normalizados = pd.get_dummies(dados.atributos)
rotulos_normalizados = dados.atributos_normalizados.columns 
# print(dados.dados.atributos.head())
# print(dados.atributos_normalizados.head())

resampler = SMOTE()
dados_atributos_b.dados.classes_b = resampler.fit_resample(dados.atributos_normalizados, dados.classes)

from collections import Counter
class_count = Counter(dados.classes_b)
print(class_count)

from sklearn.model_selection import cross_validate
scoring=['precison_macro', 'recall_macro']
scores_cross = cross_validate(rf, dados.atributos_b, dados.classes_b, cv = 10, scoring = scoring)
print('Mtriz de sensibilidades: ', scores_cross['test_precision_macro'])
print('Matriz de especificidades:', scores_cross['test_recall_macro'])

print('Especifidade:', scores_cross['test_precision_macro'].mean())
print('Sensibilidade:', scores_cross['test_recall_macro'].mean())

breast_cancer = rf.fit(dados.atriutos_b, dados.classes_b)
from pickle import dump
dump(breast_cancer, open('C:/Users/Aluno/Documents/classificadores/breast-cancer.rf.pkl', 'wb'))


# print('# FREQUENCIA DAS CLASSES APÓS O BALANCEAMENTO')
# class_count = Counter(dados.)


# frequencia das classes (atributo Output)
# dados.atributos_b = pd.DataFrame(dados.atributos_b)
# dados.atributos_b.colums = []
# dados.classes_b = pd.DataFrame(dados)